<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="70"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="71"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Эта операция требует прав администратора. Пожалуйста, перезапустите приложение и введите пароль при появлении соответствующего запроса.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>MX Service Manager</source>
        <translation>Менеджер служб MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="167"/>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>&amp;Enable at boot</source>
        <translation>&amp;Включить при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation>&amp;О программе…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="149"/>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="330"/>
        <source>All services</source>
        <translation>Все службы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <source>Running services</source>
        <translation>Запущенные службы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <source>Services enabled at boot</source>
        <translation>Службы включены при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="333"/>
        <source>Services disabled at boot</source>
        <translation>Службы отключены при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="288"/>
        <source>&amp;Refresh services</source>
        <translation>&amp;Обновить сервисы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="301"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="253"/>
        <location filename="../src/mainwindow.cpp" line="72"/>
        <location filename="../src/mainwindow.cpp" line="80"/>
        <location filename="../src/mainwindow.cpp" line="84"/>
        <source>Loading...</source>
        <translation>Загрузка...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="272"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation>Этот инструмент перечисляет службы и демоны (процессы, работающие в фоновом режиме), найденные на этой системе. Будьте осторожны, чтобы не остановить что-то, что может нарушить работу критического компонента; лучше оставить его в покое, если вы не знаете, что это такое.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="66"/>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <location filename="../src/mainwindow.cpp" line="411"/>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <location filename="../src/mainwindow.cpp" line="468"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="67"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation>Не удалось определить систему инициализации. Эта программа должна работать либо с systemd, либо с sysvinit.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="154"/>
        <location filename="../src/mainwindow.cpp" line="457"/>
        <source>S&amp;tart</source>
        <translation>Пуск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>&amp;Disable at boot</source>
        <translation>&amp;Отключить при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="366"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation>%1 общее количество, %2 в настоящее время %3работает%4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="371"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation>%1 &lt;font color=&apos;%2&apos;&gt;включено&lt;/font&gt; при загрузке, но не работает</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="388"/>
        <source>Service and daemon manager</source>
        <translation>Менеджер служб и демонов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="390"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>Could not enable %1</source>
        <translation>Не удалось включить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="408"/>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <location filename="../src/mainwindow.cpp" line="464"/>
        <location filename="../src/mainwindow.cpp" line="473"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="408"/>
        <source>%1 was enabled at boot time.</source>
        <translation>%1 было включено во время загрузки.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="411"/>
        <source>Could not disable %1</source>
        <translation>Не удалось отключить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <source>%1 was disabled.</source>
        <translation>%1 была отключена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="423"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>Refreshing...</source>
        <translation>Обновление...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <source>Could not start %1</source>
        <translation>Не удалось запустить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="464"/>
        <source>%1 was started.</source>
        <translation>%1 была запущена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="468"/>
        <source>Could not stop %1</source>
        <translation>Не удалось остановить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="473"/>
        <source>%1 was stopped.</source>
        <translation>%1 была остановлена.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="70"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <location filename="../src/about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="84"/>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You must run this program with admin access.</source>
        <translation>Вы должны запустить эту программу с правами администратора.</translation>
    </message>
    <message>
        <location filename="../src/service.cpp" line="150"/>
        <source>Could not find service description</source>
        <translation>Не удалось найти описание службы</translation>
    </message>
</context>
</TS>