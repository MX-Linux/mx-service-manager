<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="70"/>
        <source>Administrator Access Required</source>
        <translation>Zahtevan je skrbniški dostop</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="71"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Za ta operacijo je potreben skrbniški dostop. Ponovno zaženite program in vnesite geslo, ko ga bo program zahteval.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>MX Service Manager</source>
        <translation>MX upravljalnik storitev</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="167"/>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>&amp;Enable at boot</source>
        <translation>&amp;Vklopi ob zagonu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation>&amp;O programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation>Pomo&amp;č</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="149"/>
        <source>&amp;Stop</source>
        <translation>&amp;Zaustavi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="330"/>
        <source>All services</source>
        <translation>Vse storitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <source>Running services</source>
        <translation>Zagnane storitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <source>Services enabled at boot</source>
        <translation>Ob zagonu vklopljene storitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="333"/>
        <source>Services disabled at boot</source>
        <translation>Ob zagonu izklopljene storitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="288"/>
        <source>&amp;Refresh services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="301"/>
        <source>search</source>
        <translation>iskanje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="253"/>
        <location filename="../src/mainwindow.cpp" line="72"/>
        <location filename="../src/mainwindow.cpp" line="80"/>
        <location filename="../src/mainwindow.cpp" line="84"/>
        <source>Loading...</source>
        <translation>Nalaganje...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="272"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation>To orodje izpiše storitve in pritajene programe (procese, ki tečejo v ozadju), ki so bili najdeni na tem sistemu. Pri zaustavljanju teh bodite previdni, saj lahko zaustavite kritično komponento. Najbolje jih je pustiti pri miru, če ne veste kaj so.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="66"/>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <location filename="../src/mainwindow.cpp" line="411"/>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <location filename="../src/mainwindow.cpp" line="468"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="67"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation>Ni bilo mogoče določiti sistema za inicializacijo. Program naj bi bil zagnan bodisi s systemd, bodisi s sysvinit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="154"/>
        <location filename="../src/mainwindow.cpp" line="457"/>
        <source>S&amp;tart</source>
        <translation>Z&amp;aženi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>&amp;Disable at boot</source>
        <translation>&amp;Izklopi ob zagonu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="366"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation>Vseh storitev: %1; trenutno &lt;font color=&apos;%3&apos;&gt;zagnanih&lt;/font&gt; %2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="371"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation>%1 nezagnanih, a vklopljenih ob zagonu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="386"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="387"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="388"/>
        <source>Service and daemon manager</source>
        <translation>Upravljanik storitev in pritajenih programov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="390"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Avtorska zaščita (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="391"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>Could not enable %1</source>
        <translation>Nisem mogel vklopiti %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="408"/>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <location filename="../src/mainwindow.cpp" line="464"/>
        <location filename="../src/mainwindow.cpp" line="473"/>
        <source>Success</source>
        <translation>Uspešno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="408"/>
        <source>%1 was enabled at boot time.</source>
        <translation>%1 je bil vklopljen ob zagonu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="411"/>
        <source>Could not disable %1</source>
        <translation>Nisem mogel izklopiti %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="415"/>
        <source>%1 was disabled.</source>
        <translation>%1 je bil izklopljen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="423"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>Refreshing...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="459"/>
        <source>Could not start %1</source>
        <translation>Nisem mogel zagnati %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="464"/>
        <source>%1 was started.</source>
        <translation>%1 je bil zagnan.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="468"/>
        <source>Could not stop %1</source>
        <translation>Nisem mogel zaustaviti %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="473"/>
        <source>%1 was stopped.</source>
        <translation>%1 je bil zaustavljen.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="70"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <location filename="../src/about.cpp" line="81"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="72"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="84"/>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijavljeni ste kot korenski (root) uporabnik. Odjavite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You must run this program with admin access.</source>
        <translation>Ta program je potrebno zagnati s skrbniškim dostopom</translation>
    </message>
    <message>
        <location filename="../src/service.cpp" line="150"/>
        <source>Could not find service description</source>
        <translation>Opisa storitve ni bilo mogoče najti</translation>
    </message>
</context>
</TS>