<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="90"/>
        <source>Administrator Access Required</source>
        <translation>Wymagany dostęp administratora</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="91"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Ta operacja wymaga uprawnień administratora. Uruchom ponownie aplikację i wprowadź hasło, gdy zostaniesz o to poproszony.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="634"/>
        <source>MX Service Manager</source>
        <translation>MX Menedżer usług</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="217"/>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>&amp;Enable at boot</source>
        <translation>&amp;Włącz podczas rozruchu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>O programie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation>&amp;O...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>Wyświetl pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation>Pomo&amp;c</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>Zakończ program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="199"/>
        <source>&amp;Stop</source>
        <translation>&amp;Zatrzymaj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="562"/>
        <source>Running services</source>
        <translation>Uruchomione usługi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="563"/>
        <source>Services enabled at boot</source>
        <translation>Usługi włączone podczas rozruchu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <location filename="../src/mainwindow.cpp" line="564"/>
        <source>Services disabled at boot</source>
        <translation>Usługi wyłączone podczas rozruchu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <source>&amp;Refresh services</source>
        <translation>&amp;Odśwież usługi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>szukaj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="258"/>
        <location filename="../src/mainwindow.cpp" line="81"/>
        <location filename="../src/mainwindow.cpp" line="89"/>
        <location filename="../src/mainwindow.cpp" line="93"/>
        <source>Loading...</source>
        <translation>Wczytywanie...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="561"/>
        <location filename="../src/mainwindow.cpp" line="566"/>
        <source>System services</source>
        <translation>Usługi systemowe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>User services</source>
        <translation>Usługi użytkownika</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation>To narzędzie wyświetla usługi i demony (procesy działające w tle) znajdujące się w tym systemie. Uważaj, aby nie zatrzymać czegoś, co mogłoby zakłócić działanie krytycznego komponentu; najlepiej zostaw to w spokoju, jeśli nie wiesz, co to jest.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="75"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <location filename="../src/mainwindow.cpp" line="659"/>
        <location filename="../src/mainwindow.cpp" line="706"/>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="76"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation>Nie można ustalić systemu init. Ten program powinien działać albo z systemd albo sysvinit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="204"/>
        <location filename="../src/mainwindow.cpp" line="704"/>
        <source>S&amp;tart</source>
        <translation>U&amp;ruchom</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>&amp;Disable at boot</source>
        <translation>Wyłącz po&amp;dczas rozruchu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="605"/>
        <source>[User] </source>
        <translation>[Użytkownik] </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="613"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation>%1 wszystkich usług, %2 aktualnie &lt;font color=&apos;%3&apos;&gt;uruchomione&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation>%1 &lt;font color=&apos;%2&apos;&gt;włączone&lt;/font&gt; podczas rozruchu, ale nie teraz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="634"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Version: </source>
        <translation>Wersja:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Service and daemon manager</source>
        <translation>Menedżer usług i demonów</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Prawa autorskie © MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="639"/>
        <source>%1 License</source>
        <translation>%1 Licencja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Could not enable %1</source>
        <translation>Nie można włączyć %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="656"/>
        <location filename="../src/mainwindow.cpp" line="663"/>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <location filename="../src/mainwindow.cpp" line="720"/>
        <source>Success</source>
        <translation>Sukces </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="656"/>
        <source>%1 was enabled at boot time.</source>
        <translation>%1 została włączona podczas rozruchu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="659"/>
        <source>Could not disable %1</source>
        <translation>Nie można wyłączyć %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="663"/>
        <source>%1 was disabled.</source>
        <translation>%1 została wyłączona.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="680"/>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Refreshing...</source>
        <translation>Odświeżanie...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="706"/>
        <source>Could not start %1</source>
        <translation>Nie można uruchomić %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>%1 was started.</source>
        <translation>%1 została uruchomiona.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>Could not stop %1</source>
        <translation>Nie można zatrzymać %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="720"/>
        <source>%1 was stopped.</source>
        <translation>%1 została zatrzymana.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="68"/>
        <source>Could not load %1</source>
        <translation>Nie udało się załadować %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="92"/>
        <source>License</source>
        <translation>Licencja</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="93"/>
        <location filename="../src/about.cpp" line="103"/>
        <source>Changelog</source>
        <translation>Dziennik zmian</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="41"/>
        <location filename="../src/about.cpp" line="116"/>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <location filename="../src/main.cpp" line="93"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Wygląda na to, że jesteś zalogowany jako root, wyloguj się i zaloguj jako zwykły użytkownik, aby korzystać z tego programu.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You must run this program with admin access.</source>
        <translation>Musisz uruchomić ten program z uprawnieniami administratora.</translation>
    </message>
    <message>
        <location filename="../src/service.cpp" line="169"/>
        <source>Could not find service description</source>
        <translation>Nie można znaleźć opisu usługi</translation>
    </message>
</context>
</TS>