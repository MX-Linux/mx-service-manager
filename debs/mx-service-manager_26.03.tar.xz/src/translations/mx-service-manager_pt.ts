<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="71"/>
        <source>Administrator Access Required</source>
        <translation>É necessário ter permissões de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="72"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operação requer  permissões de administrador. Reinicie o programa e digite a sua senha quando esta for solicitada.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>MX Service Manager</source>
        <translation>Gestor de serviços do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>&amp;Enable at boot</source>
        <translation>&amp;Ativar no arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>Sobre esta aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation>&amp;Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>Mostrar ajuda </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>Sair da aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <source>&amp;Stop</source>
        <translation>&amp;Parar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Running services</source>
        <translation>Serviços em execução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="537"/>
        <source>Services enabled at boot</source>
        <translation>Serviços ativados no arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <location filename="../src/mainwindow.cpp" line="538"/>
        <source>Services disabled at boot</source>
        <translation>Serviços desativados no arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <source>&amp;Refresh services</source>
        <translation>&amp;Recarregar os serviços</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>procurar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="258"/>
        <location filename="../src/mainwindow.cpp" line="79"/>
        <location filename="../src/mainwindow.cpp" line="87"/>
        <location filename="../src/mainwindow.cpp" line="91"/>
        <source>Loading...</source>
        <translation>A carregar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>System services</source>
        <translation>Serviços do Sistema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="539"/>
        <source>User services</source>
        <translation>Serviços do Utilizador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation>Esta ferramenta lista os serviços e daemons (processos que são executados em segundo plano) encontrados neste sistema. Tenha cuidado para evitar parar algo que possa perturbar um componente crítico; é melhor não o interromper se não souber o que é.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="73"/>
        <location filename="../src/mainwindow.cpp" line="625"/>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <location filename="../src/mainwindow.cpp" line="680"/>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="74"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation>Não foi possível determinar o sistema de inicialização. Este programa deve ser executado com o sistema de inicialização ‘SystemD’ ou ‘SysVinit’</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>S&amp;tart</source>
        <translation>&amp;Iniciar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <source>&amp;Disable at boot</source>
        <translation>&amp;Desativar no arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="579"/>
        <source>[User] </source>
        <translation>[Utilizador] </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation>%1 serviços no total, %2 &lt;font color=&apos;%3&apos;&gt;em execução&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="592"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation>%1 &lt;font color=&apos;%2&apos;&gt;ativado(s)&lt;/font&gt; no arranque, mas não em execução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="608"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Service and daemon manager</source>
        <translation>Gestor de serviços e processos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Copyright (c) MX Linux</source>
        <translation> Direitos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="612"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="625"/>
        <source>Could not enable %1</source>
        <translation>Não foi possível ativar %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>Success</source>
        <translation>Êxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <source>%1 was enabled at boot time.</source>
        <translation>%1 foi ativado no momento do arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>Could not disable %1</source>
        <translation>Não foi possível desativar %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>%1 was disabled.</source>
        <translation>%1 estava desativado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="654"/>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <source>Refreshing...</source>
        <translation>A recarregar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="680"/>
        <source>Could not start %1</source>
        <translation>Não foi possível iniciar %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <source>%1 was started.</source>
        <translation>%1 foi iniciado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>Could not stop %1</source>
        <translation>Não foi possível parar %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>%1 was stopped.</source>
        <translation>%1 foi interrompido.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="72"/>
        <location filename="../src/about.cpp" line="82"/>
        <source>Changelog</source>
        <translation>Registo de alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <location filename="../src/main.cpp" line="93"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que tem sessão iniciada como root, por favor termine a sessão e volte a entrar como utilizador normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You must run this program with admin access.</source>
        <translation>Deve executar este programa como administrador.</translation>
    </message>
    <message>
        <location filename="../src/service.cpp" line="162"/>
        <location filename="../src/service.cpp" line="164"/>
        <source>Could not find service description</source>
        <translation>Não foi possível encontrar a descrição do serviço</translation>
    </message>
</context>
</TS>