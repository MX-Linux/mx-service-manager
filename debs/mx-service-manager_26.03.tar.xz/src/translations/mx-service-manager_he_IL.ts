<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="he_IL">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="71"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="72"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>MX Service Manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>&amp;Enable at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>אודות יישום זה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>הצגת עזרה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>יציאה מהיישום</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;סגירה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <source>&amp;Stop</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Running services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="537"/>
        <source>Services enabled at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <location filename="../src/mainwindow.cpp" line="538"/>
        <source>Services disabled at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <source>&amp;Refresh services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>חיפוש</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="258"/>
        <location filename="../src/mainwindow.cpp" line="79"/>
        <location filename="../src/mainwindow.cpp" line="87"/>
        <location filename="../src/mainwindow.cpp" line="91"/>
        <source>Loading...</source>
        <translation>כעת בטעינה...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>System services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="539"/>
        <source>User services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="73"/>
        <location filename="../src/mainwindow.cpp" line="625"/>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <location filename="../src/mainwindow.cpp" line="680"/>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="74"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="178"/>
        <location filename="../src/mainwindow.cpp" line="678"/>
        <source>S&amp;tart</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <source>&amp;Disable at boot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="579"/>
        <source>[User] </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="587"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="592"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>About %1</source>
        <translation>על אודות %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="608"/>
        <source>Version: </source>
        <translation>גרסה:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Service and daemon manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Copyright (c) MX Linux</source>
        <translation>זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="612"/>
        <source>%1 License</source>
        <translation>רישיון של %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="625"/>
        <source>Could not enable %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>Success</source>
        <translation>הצלחה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <source>%1 was enabled at boot time.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="632"/>
        <source>Could not disable %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>%1 was disabled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>%1 Help</source>
        <translation>עזרה עבור %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="654"/>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <source>Refreshing...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="680"/>
        <source>Could not start %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <source>%1 was started.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>Could not stop %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>%1 was stopped.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>License</source>
        <translation>רישיון</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="72"/>
        <location filename="../src/about.cpp" line="82"/>
        <source>Changelog</source>
        <translation>יומן שינויים</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>&amp;Close</source>
        <translation>&amp;סגירה</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <location filename="../src/main.cpp" line="93"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>כנראה שנכנסת למערכת בתור משתמש על (root), נא לצאת ולהיכנס כמשתמש רגיל כדי להשתמש בתוכנית הזאת.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/service.cpp" line="162"/>
        <location filename="../src/service.cpp" line="164"/>
        <source>Could not find service description</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>