<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="95"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="96"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>MX Service Manager</source>
        <translation>MX Servis Yönetici</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="261"/>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>&amp;Enable at boot</source>
        <translation>Açılışta &amp;etkin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>Uygulama hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation>&amp;Hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>Yardımı görüntüle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>Uygulamadan çık</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="243"/>
        <source>&amp;Stop</source>
        <translation>&amp;Dur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="716"/>
        <source>Running services</source>
        <translation>Çalışan servisler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="717"/>
        <source>Services enabled at boot</source>
        <translation>Önyüklemede etkin servisler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <location filename="../src/mainwindow.cpp" line="718"/>
        <source>Services disabled at boot</source>
        <translation>Önyüklemede devre dışı servisler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <source>&amp;Refresh services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>Ara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="258"/>
        <location filename="../src/mainwindow.cpp" line="83"/>
        <location filename="../src/mainwindow.cpp" line="101"/>
        <location filename="../src/mainwindow.cpp" line="105"/>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Loading...</source>
        <translation>Yükleniyor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <location filename="../src/mainwindow.cpp" line="720"/>
        <source>System services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>User services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation>Bu araç, bu sistemde bulunan hizmetleri ve arka plan programlarını (arka planda çalışan işlemler) listeler. Kritik bir bileşeni bozabilecek bir şeyi durdurmaktan kaçınmaya dikkat edin; Ne olduğunu bilmiyorsan, kendi haline bırakmak en iyisi.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="77"/>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <location filename="../src/mainwindow.cpp" line="874"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="78"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation>Başlatma sistemi belirlenemedi. Bu programın systemd veya sysvinit ile çalışması gerekiyor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="248"/>
        <location filename="../src/mainwindow.cpp" line="872"/>
        <source>S&amp;tart</source>
        <translation>&amp;Başlat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <source>&amp;Disable at boot</source>
        <translation>Önyüklemede &amp;devre dışı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="759"/>
        <source>[User] </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="772"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>About %1</source>
        <translation>%1 Hakkında </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <source>Version: </source>
        <translation>Sürüm:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="789"/>
        <source>Service and daemon manager</source>
        <translation>Servis ve daemon yöneticisi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="791"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Telif Hakkı (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>%1 License</source>
        <translation>%1 Lisans</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <source>Could not enable %1</source>
        <translation>%1 etkinleştirilemedi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="816"/>
        <location filename="../src/mainwindow.cpp" line="823"/>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <location filename="../src/mainwindow.cpp" line="888"/>
        <source>Success</source>
        <translation>Başarılı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="816"/>
        <source>%1 was enabled at boot time.</source>
        <translation>%1 önyükleme esnasında etkinleştirildi.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <source>Could not disable %1</source>
        <translation>%1 devre dışı bırakılamadı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="823"/>
        <source>%1 was disabled.</source>
        <translation>%1 devre dışı bırakıldı.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="830"/>
        <source>%1 Help</source>
        <translation>%1 Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="840"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>Refreshing...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="874"/>
        <source>Could not start %1</source>
        <translation>%1 başlatılamadı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <source>%1 was started.</source>
        <translation>%1 başlatıldı.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>Could not stop %1</source>
        <translation>%1 durdurulamadı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="888"/>
        <source>%1 was stopped.</source>
        <translation>%1 durduruldu.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="68"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="92"/>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="93"/>
        <location filename="../src/about.cpp" line="103"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="41"/>
        <location filename="../src/about.cpp" line="116"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <location filename="../src/main.cpp" line="93"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Görünüşe göre root olarak girmişsiniz, lütfen çıkın ve bu programı kullanmak için normal kullanıcı olarak girin. </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You must run this program with admin access.</source>
        <translation>Bu programı yönetici erişimiyle çalıştırmalısınız.</translation>
    </message>
    <message>
        <location filename="../src/service.cpp" line="170"/>
        <source>Could not find service description</source>
        <translation>Bu programı yönetici erişimiyle çalıştırmalısınız.</translation>
    </message>
</context>
</TS>