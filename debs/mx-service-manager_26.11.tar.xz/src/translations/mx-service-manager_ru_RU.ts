<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="95"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="96"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Эта операция требует прав администратора. Пожалуйста, перезапустите приложение и введите пароль при появлении соответствующего запроса.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>MX Service Manager</source>
        <translation>Менеджер служб MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="26"/>
        <location filename="../src/mainwindow.cpp" line="261"/>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>&amp;Enable at boot</source>
        <translation>&amp;Включить при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="62"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>&amp;About...</source>
        <translation>&amp;О программе…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="175"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="216"/>
        <location filename="../src/mainwindow.cpp" line="243"/>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="240"/>
        <location filename="../src/mainwindow.cpp" line="716"/>
        <source>Running services</source>
        <translation>Запущенные службы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <location filename="../src/mainwindow.cpp" line="717"/>
        <source>Services enabled at boot</source>
        <translation>Службы включены при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="250"/>
        <location filename="../src/mainwindow.cpp" line="718"/>
        <source>Services disabled at boot</source>
        <translation>Службы отключены при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <source>&amp;Refresh services</source>
        <translation>&amp;Обновить сервисы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="258"/>
        <location filename="../src/mainwindow.cpp" line="83"/>
        <location filename="../src/mainwindow.cpp" line="101"/>
        <location filename="../src/mainwindow.cpp" line="105"/>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Loading...</source>
        <translation>Загрузка...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="230"/>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <location filename="../src/mainwindow.cpp" line="720"/>
        <source>System services</source>
        <translation>Системные службы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="235"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>User services</source>
        <translation>Пользовательские сервисы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <source>This tool lists services and daemons (processes that run in the background) found on this system. Be careful to avoid stopping something that might disrupt a critical component; best to leave it alone if you don&apos;t know what it is.</source>
        <translation>Этот инструмент перечисляет службы и демоны (процессы, работающие в фоновом режиме), найденные на этой системе. Будьте осторожны, чтобы не остановить что-то, что может нарушить работу критического компонента; лучше оставить его в покое, если вы не знаете, что это такое.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="77"/>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <location filename="../src/mainwindow.cpp" line="874"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="78"/>
        <source>Could not determine the init system. This program is supposed to run either with systemd or sysvinit</source>
        <translation>Не удалось определить систему инициализации. Эта программа должна работать либо с systemd, либо с sysvinit.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="248"/>
        <location filename="../src/mainwindow.cpp" line="872"/>
        <source>S&amp;tart</source>
        <translation>Пуск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <source>&amp;Disable at boot</source>
        <translation>&amp;Отключить при загрузке</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="759"/>
        <source>[User] </source>
        <translation>[Пользователь]</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>%1 total services, %2 currently &lt;font color=&apos;%3&apos;&gt;running&lt;/font&gt;</source>
        <translation>%1 общее количество, %2 в настоящее время &lt;font color=&apos;%3&apos;&gt;работает&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="772"/>
        <source>%1 &lt;font color=&apos;%2&apos;&gt;enabled&lt;/font&gt; at boot, but not running</source>
        <translation>%1 &lt;font color=&apos;%2&apos;&gt;включено&lt;/font&gt; при загрузке, но не работает</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="789"/>
        <source>Service and daemon manager</source>
        <translation>Менеджер служб и демонов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="791"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <source>Could not enable %1</source>
        <translation>Не удалось включить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="816"/>
        <location filename="../src/mainwindow.cpp" line="823"/>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <location filename="../src/mainwindow.cpp" line="888"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="816"/>
        <source>%1 was enabled at boot time.</source>
        <translation>%1 было включено во время загрузки.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <source>Could not disable %1</source>
        <translation>Не удалось отключить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="823"/>
        <source>%1 was disabled.</source>
        <translation>%1 была отключена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="830"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="840"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>Refreshing...</source>
        <translation>Обновление...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="874"/>
        <source>Could not start %1</source>
        <translation>Не удалось запустить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <source>%1 was started.</source>
        <translation>%1 была запущена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>Could not stop %1</source>
        <translation>Не удалось остановить %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="888"/>
        <source>%1 was stopped.</source>
        <translation>%1 была остановлена.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="68"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="92"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="93"/>
        <location filename="../src/about.cpp" line="103"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="41"/>
        <location filename="../src/about.cpp" line="116"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <location filename="../src/main.cpp" line="93"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You must run this program with admin access.</source>
        <translation>Вы должны запустить эту программу с правами администратора.</translation>
    </message>
    <message>
        <location filename="../src/service.cpp" line="170"/>
        <source>Could not find service description</source>
        <translation>Не удалось найти описание службы</translation>
    </message>
</context>
</TS>