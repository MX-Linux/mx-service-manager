# **********************************************************************
# * Copyright (C) 2023-2026 MX Authors
# *
# * Authors: Adrian <adrian@mxlinux.org>
# *          MX Linux <http://mxlinux.org>
# *
# * This is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this package. If not, see <http://www.gnu.org/licenses/>.
# **********************************************************************/

cmake_minimum_required(VERSION 3.16)

set(PROJECT_VERSION_FROM_CHANGELOG "")

if(DEFINED PROJECT_VERSION_OVERRIDE AND NOT "${PROJECT_VERSION_OVERRIDE}" STREQUAL "")
    set(PROJECT_VERSION_FROM_CHANGELOG "${PROJECT_VERSION_OVERRIDE}")
    message(STATUS "Using version override: ${PROJECT_VERSION_FROM_CHANGELOG}")
else()
    # Try dpkg-parsechangelog first (Debian/Ubuntu)
    execute_process(
        COMMAND dpkg-parsechangelog -SVersion
        WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}
        OUTPUT_VARIABLE PROJECT_VERSION_FROM_CHANGELOG
        OUTPUT_STRIP_TRAILING_WHITESPACE
        RESULT_VARIABLE DPKG_RESULT
        ERROR_QUIET
    )

    if(DPKG_RESULT EQUAL 0 AND NOT "${PROJECT_VERSION_FROM_CHANGELOG}" STREQUAL "")
        message(STATUS "Using version from debian/changelog: ${PROJECT_VERSION_FROM_CHANGELOG}")
    elseif(EXISTS ${CMAKE_SOURCE_DIR}/debian/changelog)
        file(READ ${CMAKE_SOURCE_DIR}/debian/changelog PROJECT_CHANGELOG_CONTENT)
        string(REGEX MATCH "^[^\\(]*\\(([^)]+)\\)" _match "${PROJECT_CHANGELOG_CONTENT}")
        if(NOT _match)
            message(FATAL_ERROR "Could not parse version from debian/changelog")
        endif()
        set(PROJECT_VERSION_FROM_CHANGELOG "${CMAKE_MATCH_1}")
        message(STATUS "Using version parsed from debian/changelog: ${PROJECT_VERSION_FROM_CHANGELOG}")
    else()
        message(FATAL_ERROR "Could not determine version: dpkg-parsechangelog not available and debian/changelog missing")
    endif()
endif()

# CMake project() VERSION only accepts numeric components; strip any alpha suffix (e.g. "26.02arch" -> "26.02")
string(REGEX REPLACE "[a-zA-Z]+.*$" "" PROJECT_VERSION_NUMERIC "${PROJECT_VERSION_FROM_CHANGELOG}")

project(mx-service-manager
    VERSION ${PROJECT_VERSION_NUMERIC}
    DESCRIPTION "Service Manager - MX Linux service management tool"
    LANGUAGES CXX
)

include(GNUInstallDirs)

# Set C++ standard
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Enable compile commands export for IDEs and tools
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Optimize for Ninja builds
if(CMAKE_GENERATOR STREQUAL "Ninja")
    # Enable colored output for Ninja
    if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
        add_compile_options(-fdiagnostics-color=always)
    elseif(CMAKE_CXX_COMPILER_ID STREQUAL "Clang")
        add_compile_options(-fcolor-diagnostics)
    endif()
endif()

# Option to use clang for testing builds
option(USE_CLANG "Use clang compiler" OFF)
if(USE_CLANG)
    set(CMAKE_C_COMPILER clang)
    set(CMAKE_CXX_COMPILER clang++)
    set(CMAKE_CXX_COMPILER_ID "Clang")
    message(STATUS "Using clang compiler")
endif()

# Find Qt6 components
find_package(Qt6 REQUIRED COMPONENTS
    Core
    Gui
    Widgets
    LinguistTools
    Concurrent
)

# Enable automatic MOC, UIC, and RCC processing
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

# Absolute directory where the privileged helper binary is installed.
set(HELPER_INSTALL_DIR "/usr/libexec/mx-service-manager" CACHE PATH
    "Absolute install directory for the privileged helper binary")
if(NOT IS_ABSOLUTE "${HELPER_INSTALL_DIR}")
    message(FATAL_ERROR "HELPER_INSTALL_DIR must be an absolute path, got: ${HELPER_INSTALL_DIR}")
endif()
set(HELPER_PATH "${HELPER_INSTALL_DIR}/helper")
set(POLKIT_ACTION_DIR "/usr/share/polkit-1/actions" CACHE PATH "System polkit action directory")
file(RELATIVE_PATH APP_LOCALE_DIR "${CMAKE_INSTALL_FULL_BINDIR}" "${CMAKE_INSTALL_FULL_DATADIR}/mx-service-manager/locale")
file(RELATIVE_PATH APP_DOC_DIR "${CMAKE_INSTALL_FULL_BINDIR}" "${CMAKE_INSTALL_FULL_DOCDIR}")

configure_file(
    scripts/org.mxlinux.pkexec.mxsm-helper.policy.in
    ${CMAKE_BINARY_DIR}/org.mxlinux.pkexec.mxsm-helper.policy
    @ONLY
)

# Define source files
set(SOURCES
    src/main.cpp
    src/mainwindow.cpp
    src/about.cpp
    src/cmd.cpp
    src/service.cpp
)

set(HEADERS
    src/mainwindow.h
    src/about.h
    src/cmd.h
    src/service.h
    src/common.h
)

set(UI_FILES
    src/mainwindow.ui
)

set(RESOURCE_FILES
    images.qrc
)

# Get all translation files
file(GLOB TRANSLATION_FILES "translations/*.ts")
list(FILTER TRANSLATION_FILES EXCLUDE REGEX "/mx-service-manager_en_US\\.ts$")

# Create the executable
add_executable(mx-service-manager
    ${SOURCES}
    ${HEADERS}
    ${UI_FILES}
    ${RESOURCE_FILES}
)

# Link Qt6 libraries
target_link_libraries(mx-service-manager
    Qt6::Core
    Qt6::Gui
    Qt6::Widgets
    Qt6::Concurrent
)

# Set compiler flags
target_compile_options(mx-service-manager PRIVATE
    -pedantic
    -Werror=return-type
    -Werror=switch
    -Werror=uninitialized
    -Werror
)

# Add compiler-specific flags
if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR USE_CLANG)
    target_compile_options(mx-service-manager PRIVATE -Werror=return-stack-address)
else()
    target_compile_options(mx-service-manager PRIVATE -Werror=return-local-addr)
endif()

# Set compile definitions
target_compile_definitions(mx-service-manager PRIVATE
    HELPER_PATH="${HELPER_PATH}"
    APP_LOCALE_DIR="${APP_LOCALE_DIR}"
    APP_DOC_DIR="${APP_DOC_DIR}"
)

target_compile_definitions(mx-service-manager PRIVATE
    QT_DEPRECATED_WARNINGS
    QT_DISABLE_DEPRECATED_BEFORE=0x060000
    VERSION="${PROJECT_VERSION_FROM_CHANGELOG}"
)

# Release-specific optimizations
if(CMAKE_BUILD_TYPE STREQUAL "Release")
    target_compile_definitions(mx-service-manager PRIVATE NDEBUG)
    target_compile_options(mx-service-manager PRIVATE -O3)

    # Add LTO - different flags for different compilers
    if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR USE_CLANG)
        target_compile_options(mx-service-manager PRIVATE -flto=thin)
        target_link_options(mx-service-manager PRIVATE -flto=thin)
    else()
        target_compile_options(mx-service-manager PRIVATE -flto=auto)
        target_link_options(mx-service-manager PRIVATE -flto=auto)
    endif()
endif()

# Test infrastructure
option(BUILD_TESTS "Build tests" OFF)
if(BUILD_TESTS)
    enable_testing()
    foreach(option IN ITEMS -h --help --help-all -v --version)
        add_test(NAME cli${option} COMMAND ${CMAKE_COMMAND} -E env
            --unset=DISPLAY --unset=WAYLAND_DISPLAY --unset=QT_QPA_PLATFORM
            $<TARGET_FILE:mx-service-manager> ${option})
        set_tests_properties(cli${option} PROPERTIES TIMEOUT 10)
    endforeach()
    add_test(NAME helper_smoke COMMAND helper true)
endif()

# Handle translations
qt6_add_translations(mx-service-manager
    TS_FILES ${TRANSLATION_FILES}
    LRELEASE_OPTIONS -compress -nounfinished -removeidentical -silent
    QM_FILES_OUTPUT_VARIABLE qm_files
)

# Set target properties
set_target_properties(mx-service-manager PROPERTIES
    OUTPUT_NAME "mx-service-manager"
    RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}
)

# Helper executable (compiled privileged helper — no bash fallthrough)
add_executable(helper
    src/helper.cpp
)

target_link_libraries(helper
    Qt6::Core
)

target_compile_options(helper PRIVATE
    -pedantic
    -Werror=return-type
    -Werror=switch
    -Werror=uninitialized
    -Werror
)

if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR USE_CLANG)
    target_compile_options(helper PRIVATE -Werror=return-stack-address)
else()
    target_compile_options(helper PRIVATE -Werror=return-local-addr)
endif()

target_compile_definitions(helper PRIVATE
    QT_DEPRECATED_WARNINGS
    QT_DISABLE_DEPRECATED_BEFORE=0x060000
)

if(CMAKE_BUILD_TYPE STREQUAL "Release")
    target_compile_definitions(helper PRIVATE NDEBUG)
    target_compile_options(helper PRIVATE -O3)
    if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR USE_CLANG)
        target_compile_options(helper PRIVATE -flto=thin)
        target_link_options(helper PRIVATE -flto=thin)
    else()
        target_compile_options(helper PRIVATE -flto=auto)
        target_link_options(helper PRIVATE -flto=auto)
    endif()
endif()

install(TARGETS mx-service-manager RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}")
install(TARGETS helper RUNTIME DESTINATION "${HELPER_INSTALL_DIR}")
install(FILES "${CMAKE_BINARY_DIR}/org.mxlinux.pkexec.mxsm-helper.policy" DESTINATION "${POLKIT_ACTION_DIR}")
install(FILES ${qm_files} DESTINATION "${CMAKE_INSTALL_DATADIR}/mx-service-manager/locale")
install(FILES mx-service-manager.desktop DESTINATION "${CMAKE_INSTALL_DATADIR}/applications")
install(FILES mx-service-manager.png DESTINATION "${CMAKE_INSTALL_DATADIR}/icons/hicolor/64x64/apps")
install(FILES mx-service-manager.png DESTINATION "${CMAKE_INSTALL_DATADIR}/pixmaps")
install(DIRECTORY docs/ DESTINATION "${CMAKE_INSTALL_DOCDIR}")
install(FILES debian/changelog DESTINATION "${CMAKE_INSTALL_DOCDIR}")
install(FILES help/mx-service-manager.1 DESTINATION "${CMAKE_INSTALL_MANDIR}/man1")
